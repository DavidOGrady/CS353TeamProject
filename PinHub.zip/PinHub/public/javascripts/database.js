/**
 * Created by DavidOGrady on 09/11/2016.
 */
function databaseint() {
    var config = {
        apiKey: "AIzaSyDgiEhjL5nUO3zEkxaLZ9LE56j2tCt94ME",
        authDomain: "lab2-e3fae.firebaseapp.com",
        databaseURL: "https://lab2-e3fae.firebaseio.com",
        storageBucket: "lab2-e3fae.appspot.com",
        messagingSenderId: "374679842253"
    };
    var database = firebase.initializeApp(config);
    return database;
}