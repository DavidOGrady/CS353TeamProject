var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
    res.writeHead(200,{"Content-Type":"text/html"});
    res.write("This will be the user profile page.");
    console.log("We got to the /route/profile.js");
    //res.render('profile',);
});

module.exports = router;